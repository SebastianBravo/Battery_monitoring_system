/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.7
        Device            :  PIC18F47K42
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include <xc.h>
#include "mcc_generated_files/mcc.h"
#include "timer0.h"
#include "adc.h"
#include "uart.h"

uint16_t multiplo(float Ts, float des_Ts);
void SPI_transmit(void);

uint8_t n_canales = 2;
uint8_t canal_actual = 0;
uint8_t lectura_done = 0;
uint8_t rx_done = 0;


uint16_t lecturas[2];
uint8_t lecturas_ascii[9] = {0,0,0,0,0,0,0,0,0xA};

uint8_t command[3];
uint16_t command_bcd;
uint8_t command[3];
uint8_t command_length = 3;

uint8_t prueba = 0;

float Ts = 0.0001;
float des_Ts = 0.0005;
uint16_t count = 1;
uint16_t k = 1;

uint16_t spi_con = 0x80;

/*
                         Main application
 */
void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();
    uart_config(256000, 1);
    timer0_config();
    voltage_ref_config();
    adc_config(1);
    SPI1_Initialize();
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global Interrupts
    // Use the following macros to:

    // Enable the Global Interrupts
    // INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts
    // INTERRUPT_GlobalInterruptDisable();
    k =  multiplo(Ts, des_Ts);
    LATEbits.LE0 = 1;
    LATBbits.LB4 = 1;
    
    while (1)
    {
        if(rx_done){
            rx_done = 0;
            hexascii_2_bcd(&command_bcd, command);
            k =  multiplo(Ts, command_bcd*0.0001);
        }
        if(lectura_done){
            lectura_done = 0;
      
            SPI_transmit();
            
            bcd_2_hexascii(lecturas[0], lecturas_ascii, 0);
            bcd_2_hexascii(lecturas[1], lecturas_ascii, 4);
            send_array(lecturas_ascii);
        }
    }
}

void __interrupt() ISR(void)
{   
    // ISR RX
    if(PIR3bits.U1RXIF){
        read_buffer(command, command_length, &rx_done);
    }
    //ISR TMR0
    if(PIR3bits.TMR0IF){
        timer0_reset();
        
        if(count < k-1){
            count++;
        }else{
            count = 0;
            LATDbits.LD0=~LATDbits.LD0;
            start_conversion(0);
        }
    }
    // ISR TX
    if(PIR3bits.U1TXIF){
        send_buffer();          // Envia dato correspondiente de buffer
    }
    // ISR ADC
    if(PIR1bits.ADIF){
        LATDbits.LD1 = 0;
        lectura_done = read_n_adc(lecturas, &canal_actual, n_canales);
    }  
}
/**
 End of File
*/

uint16_t multiplo(float Ts, float des_Ts){
    return des_Ts/Ts;
}

void SPI_transmit(void){
    
    // Habilitar SPI
    SPI1_Openv2();
    
    // Habilitar DAC
    LATEbits.LE0 = 0;
    
    // Canal 1
    SPI1TXB = 0x20 | (lecturas[0] >> 8);
    SPI1TXB = lecturas[0];
    
    //Esperar a que se envie canal 1
    while(!SPI1STATUSbits.TXBE);
   
    // Deshabilitar DAC
    LATEbits.LE0 = 1;
    
    // LDAC
    LATBbits.LB4 = 0;
    LATBbits.LB4 = 0;
    LATBbits.LB4 = 0;
    LATBbits.LB4 = 1;
    LATBbits.LB4 = 1;
    LATBbits.LB4 = 1;
    LATBbits.LB4 = 1;
    LATBbits.LB4 = 1;
    LATBbits.LB4 = 1;
    LATBbits.LB4 = 1;
    
    // Habilitar DAC
    LATEbits.LE0 = 0;
    
    // Canal 2
    SPI1TXB = 0xA0 | (lecturas[1] >> 8);
    SPI1TXB = lecturas[1];
    
    //Esperar a que se envie canal 2
    while(!SPI1STATUSbits.TXBE);
    
    // Deshabilitar DAC
    LATEbits.LE0 = 1;
    
    // LDAC
    LATBbits.LB4 = 0;
    LATBbits.LB4 = 0;
    LATBbits.LB4 = 0;
    LATBbits.LB4 = 1;
    
    // Deshabilitar SPI
    SPI1_Close();
}